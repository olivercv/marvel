from pydantic import BaseModel

class CharacterResponse(BaseModel):
    id: int
    name: str
    description: str

    class Config:
        orm_mode = True