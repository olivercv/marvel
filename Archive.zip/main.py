from fastapi import FastAPI, HTTPException, Path
from pydantic import BaseModel
from typing import List, Optional
import hashlib
import time
import requests
from dotenv import load_dotenv
import os

load_dotenv()

app = FastAPI()

MARVEL_PUBLIC_KEY = os.getenv("389603008f95a02eedbf037ed51fe418")
MARVEL_PRIVATE_KEY = os.getenv("41a995f35d3be6fe470420088a58c37f3ce66343")

# Base de datos simulada
characters_db = []

# Modelo de MarvelCharacter (el que usamos para la base de datos)
class MarvelCharacter(BaseModel):
    id: int
    name: str
    description: Optional[str] = "No description available"
    modified: Optional[str] = None

# Modelo para los datos de entrada (esquema)
class CharacterCreate(BaseModel):
    name: str
    description: Optional[str] = None

# Función para generar hash
def generate_hash(ts: str):
    hash_str = ts + MARVEL_PRIVATE_KEY + MARVEL_PUBLIC_KEY
    return hashlib.md5(hash_str.encode()).hexdigest()

# Obtener un personaje desde la API de Marvel (GET)
@app.get("/character/{character_id}", response_model=MarvelCharacter)
def get_character(character_id: int):
    ts = str(time.time())
    hash_md5 = generate_hash(ts)
    url = f"https://gateway.marvel.com/v1/public/characters/{character_id}"
    params = {
        "ts": ts,
        "apikey": MARVEL_PUBLIC_KEY,
        "hash": hash_md5
    }
    response = requests.get(url, params=params)
    if response.status_code != 200:
        raise HTTPException(status_code=404, detail="Character not found")
    
    data = response.json()
    if not data["data"]["results"]:
        raise HTTPException(status_code=404, detail="Character not found")
    
    result = data["data"]["results"][0]
    character = MarvelCharacter(
        id=result["id"],
        name=result["name"],
        description=result["description"] or "No description available",
        modified=result["modified"]
    )
    return character

# Crear un personaje (POST)
@app.post("/character/", response_model=MarvelCharacter)
def create_character(character: CharacterCreate):
    new_id = len(characters_db) + 1
    new_character = MarvelCharacter(
        id=new_id,
        name=character.name,
        description=character.description,
        modified=str(time.time())
    )
    characters_db.append(new_character)
    return new_character

# Listar todos los personajes (GET)
@app.get("/characters/", response_model=List[MarvelCharacter])
def list_characters():
    return characters_db

# Editar un personaje (PUT)
@app.put("/character/{character_id}", response_model=MarvelCharacter)
def update_character(character_id: int, updated_character: CharacterCreate):
    for character in characters_db:
        if character.id == character_id:
            character.name = updated_character.name
            character.description = updated_character.description
            character.modified = str(time.time())
            return character
    raise HTTPException(status_code=404, detail="Character not found")

# Eliminar un personaje (DELETE)
@app.delete("/character/{character_id}", response_model=dict)
def delete_character(character_id: int):
    for character in characters_db:
        if character.id == character_id:
            characters_db.remove(character)
            return {"message": "Character deleted successfully"}
    raise HTTPException(status_code=404, detail="Character not found")
