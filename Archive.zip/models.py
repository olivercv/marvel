from pydantic import BaseModel

class MarvelCharacter(BaseModel):
    id: int
    name: str
    description: str
    modified: str